classdef ResetNeuron < SimpleNeuron
	%RESETNEURON dendritic potential is set to zero after spike
	
	properties
	end
	
	methods
	end
	
end

